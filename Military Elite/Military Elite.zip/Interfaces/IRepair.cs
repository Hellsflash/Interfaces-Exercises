﻿public interface IRepair
{
    string PartName { get; set; }
    int WorkHours { get; set; }
}