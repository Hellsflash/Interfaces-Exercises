﻿public interface ISpecialisedSoldier : IPrivate
{
    string Corp { get; set; }
}